document.addEventListener('DOMContentLoaded', function () {
    console.log('Document ready');
    let fileResultsTable = null; // Riferimento alla tabella dei risultati
    let xhr = null; // Riferimento all'oggetto XMLHttpRequest

    function startLoadingFiles(minSize, maxSize) {
        document.getElementById('large-file-cleaner-progress').innerHTML = '<p>Caricamento in corso...</p>';
        document.getElementById('large-file-cleaner-results').innerHTML = ''; // Pulisci i risultati precedenti
        fileResultsTable = createResultsTable(); // Crea la tabella all'inizio

        xhr = new XMLHttpRequest();
        xhr.open('POST', large_file_cleaner_vars.ajaxurl, true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');

        xhr.onprogress = function (event) { // Gestisci i dati in arrivo
            if (event.lengthComputable) {
                // Aggiorna la barra di avanzamento se possibile
            } else {
                const responseLines = event.target.responseText.split('\n');

                // Parsa ogni riga come un oggetto JSON separato
                responseLines.forEach(line => {
                    if (line.trim() !== '') { // Ignora le righe vuote
                        try {
                            const lastLine = JSON.parse(line);

                            if (lastLine.status === 'running') {
                                updateResultsTable(lastLine.files || []);
                            } else if (lastLine.status === 'complete') {
                                var progressHtml = '<p>Scansione completata.</p>';
                                document.getElementById('large-file-cleaner-progress').innerHTML = progressHtml;
                            }
                        } catch (error) {
                            console.error("Errore nel parsing della riga:", line, error);
                        }
                    }
                });
            }
        };

        xhr.onload = function () {
            if (xhr.status === 200) {
                clearInterval(interval);
            } else {
                console.error('Error checking progress', xhr.statusText);
                clearInterval(interval);
            }
        };

        xhr.send('action=large_file_cleaner_get_files&min_size=' + minSize + '&max_size=' + maxSize);
        var interval = setInterval(() => {}, 1000);
    }

    function createResultsTable() {
        const resultsDiv = document.getElementById('large-file-cleaner-results');
        const table = document.createElement('table');
        table.innerHTML = '<tr><th>File</th><th>Dimensione</th><th>Azioni</th></tr>';
        resultsDiv.appendChild(table);
        const deleteAllButton = document.createElement('button');
        deleteAllButton.textContent = 'Elimina tutti i file';
        deleteAllButton.id = 'delete-all-files';
        deleteAllButton.classList.add('button', 'button-secondary');
        deleteAllButton.addEventListener('click', function () {
            if (confirm('Sei sicuro di voler eliminare tutti i file trovati? Questa azione non può essere annullata.')) {
                deleteAllFiles();
            }
        });
        resultsDiv.appendChild(deleteAllButton);

        const stopButton = document.createElement('button'); // Aggiungi il pulsante di stop
        stopButton.textContent = 'Stop';
        stopButton.id = 'stop-search';
        stopButton.classList.add('button', 'button-secondary');
        stopButton.addEventListener('click', function () {
            if (xhr) {
                xhr.abort();
                document.getElementById('large-file-cleaner-progress').innerHTML = '<p>Scansione fermata.</p>';
            }
        });
        resultsDiv.appendChild(stopButton);

        return table;
    }

    function updateResultsTable(files) {
        files.forEach(function (file) {
            // Controlla se la riga esiste già per evitare duplicati
            if (!document.querySelector(`tr[data-file-id="${file.file_id}"]`)) {
                const newRow = fileResultsTable.insertRow();
                newRow.dataset.fileId = file.file_id;
                newRow.innerHTML = `
                    <td>${file.path}</td>
                    <td>${sizeFormat(file.size)}</td>
                    <td><button class="delete-file button button-secondary" data-file="${file.file_id}">Elimina</button></td>
                `;
                // Aggiungi l'event listener al nuovo pulsante "Elimina"
                newRow.querySelector('.delete-file').addEventListener('click', function (event) {
                    deleteFile(event.target);
                });
            }
        });
    }

    function deleteFile(button) {
        var file = button.getAttribute('data-file');
        var xhr = new XMLHttpRequest();
        xhr.open('POST', large_file_cleaner_vars.ajaxurl, true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
        xhr.onload = function () {
            if (xhr.status === 200) {
                console.log('File deleted', xhr.responseText);
                button.closest('tr').remove();
            } else {
                console.error('Error deleting file', xhr.statusText);
            }
        };
        xhr.send('action=large_file_cleaner_delete_file&file=' + file);
    }

    function deleteAllFiles() {
        const allFileRows = fileResultsTable.querySelectorAll('tr[data-file-id]');
        const filesToDelete = Array.from(allFileRows).map(row => row.dataset.fileId);

        var xhr = new XMLHttpRequest();
        xhr.open('POST', large_file_cleaner_vars.ajaxurl, true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
        xhr.onload = function () {
            if (xhr.status === 200) {
                alert(xhr.responseText);
                document.getElementById('large-file-cleaner-results').innerHTML = '';
                fileResultsTable = null; // Reimposta il riferimento alla tabella
            } else {
                console.error('Errore durante l\'eliminazione dei file:', xhr.statusText);
            }
        };
        xhr.send('action=large_file_cleaner_delete_all_files&files=' + encodeURIComponent(JSON.stringify(filesToDelete)));
    }

    document.getElementById('search-files').addEventListener('click', function () {
        console.log('Search button clicked');
        var minSize = document.getElementById('min-file-size').value;
        var maxSize = document.getElementById('max-file-size').value;
        startLoadingFiles(minSize, maxSize);
    });
});

function sizeFormat(bytes) {
    if (bytes === 0) { return '0 B'; }
    var k = 1024;
    var sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    var i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(3)) + ' ' + sizes[i]; // Modifica per mostrare fino a 3 decimali
}