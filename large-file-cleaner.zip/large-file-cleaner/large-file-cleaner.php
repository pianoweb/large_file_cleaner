<?php

/**
 * Plugin Name: Large File Cleaner
 * Description: Elimina file di grandi dimensioni non utilizzati e pulisce il database.
 * Version: 1.2
 * Author: Il tuo Nome
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Large_File_Cleaner
{
    public function __construct()
    {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_ajax_large_file_cleaner_get_files', array($this, 'large_file_cleaner_get_files'));
        add_action('wp_ajax_large_file_cleaner_delete_file', array($this, 'large_file_cleaner_delete_file'));
        add_action('wp_ajax_large_file_cleaner_delete_all_files', array($this, 'large_file_cleaner_delete_all_files'));
    }

    public function add_admin_menu()
    {
        add_menu_page(
            'Large File Cleaner',
            'Large File Cleaner',
            'manage_options',
            'large-file-cleaner',
            array($this, 'create_admin_page'),
            'dashicons-trash',
            100
        );
    }

    public function enqueue_scripts($hook)
    {
        if ($hook !== 'toplevel_page_large-file-cleaner') {
            return;
        }
        $version = time();
        wp_enqueue_script('large-file-cleaner-script', plugin_dir_url(__FILE__) . 'js/large-file-cleaner.js', array(), $version, true);
        wp_enqueue_style('large-file-cleaner-style', plugin_dir_url(__FILE__) . 'css/large-file-cleaner.css', array(), $version);
        wp_localize_script('large-file-cleaner-script', 'large_file_cleaner_vars', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
        ));
    }

    public function create_admin_page()
    {
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Large File Cleaner', 'large-file-cleaner'); ?></h1>
            <form id="large-file-cleaner-form">
                <label for="min-file-size"><?php esc_html_e('Enter minimum file size in KB:', 'large-file-cleaner'); ?></label>
                <input type="number" step="0.001" id="min-file-size" name="min-file-size" min="0" value="0">
                <label for="max-file-size"><?php esc_html_e('Enter maximum file size in KB:', 'large-file-cleaner'); ?></label>
                <input type="number" step="0.001" id="max-file-size" name="max-file-size" min="0" value="5000">
                <button type="button" id="search-files" class="button button-primary"><?php esc_html_e('Search Files', 'large-file-cleaner'); ?></button>
            </form>
            <div id="large-file-cleaner-progress" style="margin-top: 20px;"></div>
            <div id="large-file-cleaner-results" style="margin-top: 20px;"></div>
        </div>
        <?php
    }

    public function large_file_cleaner_get_files()
    {
        $min_size = isset($_POST['min_size']) ? floatval($_POST['min_size']) * 1024 : 0;
        $max_size = isset($_POST['max_size']) ? floatval($_POST['max_size']) * 1024 : 5000000;

        $root_dir = ABSPATH;

        // Imposta un limite di tempo più lungo per evitare timeout
        set_time_limit(0);

        $this->scan_directory($root_dir, $min_size, $max_size);

        wp_die();
    }

    private function scan_directory($dir, $min_size, $max_size)
    {
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );

        header('Content-Type: application/json');

        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $file_size = $file->getSize();
                if ($file_size >= $min_size && $file_size <= $max_size) {
                    $file_data = array(
                        'path' => $file->getPathname(),
                        'size' => $file_size,
                        'file_id' => esc_attr($file->getPathname())
                    );

                    echo json_encode(['status' => 'running', 'files' => [$file_data]]) . "\n";
                    ob_flush();
                    flush();
                    usleep(100000);
                }
            }
        }

        echo json_encode(['status' => 'complete']) . "\n";
        ob_flush();
        flush();
    }

    public function large_file_cleaner_delete_file()
    {
        if (isset($_POST['file'])) {
            $file_path = sanitize_text_field($_POST['file']);

            if (file_exists($file_path)) {
                // Elimina il file originale
                unlink($file_path);

                // Controlla se il file è un allegato di WordPress e, in tal caso, elimina le sue voci dal database
                $file_id = attachment_url_to_postid(wp_get_attachment_url($file_path));
                if ($file_id) {
                    // Elimina tutte le dimensioni dell'immagine
                    $meta = wp_get_attachment_metadata($file_id);
                    if (isset($meta['sizes']) && is_array($meta['sizes'])) {
                        $upload_dir = wp_upload_dir();
                        foreach ($meta['sizes'] as $size) {
                            $size_path = $upload_dir['basedir'] . '/' . dirname($meta['file']) . '/' . $size['file'];
                            if (file_exists($size_path)) {
                                unlink($size_path);
                            }
                        }
                    }

                    // Elimina la voce nel database
                    wp_delete_attachment($file_id, true);
                }

                echo 'File e tutte le sue dimensioni eliminate.';
            } else {
                echo 'File non trovato.';
            }
        }

        wp_die();
    }

    public function large_file_cleaner_delete_all_files()
    {
        if (isset($_POST['files'])) {
            $files = json_decode(stripslashes($_POST['files']), true);
            if (is_array($files)) {
                foreach ($files as $file_path) {
                    $file_path = sanitize_text_field($file_path);
                    if (file_exists($file_path)) {
                        // Elimina il file originale
                        unlink($file_path);

                        // Controlla se il file è un allegato di WordPress e, in tal caso, elimina le sue voci dal database
                        $file_id = attachment_url_to_postid(wp_get_attachment_url($file_path));
                        if ($file_id) {
                            // Elimina tutte le dimensioni dell'immagine
                            $meta = wp_get_attachment_metadata($file_id);
                            if (isset($meta['sizes']) && is_array($meta['sizes'])) {
                                $upload_dir = wp_upload_dir();
                                foreach ($meta['sizes'] as $size) {
                                    $size_path = $upload_dir['basedir'] . '/' . dirname($meta['file']) . '/' . $size['file'];
                                    if (file_exists($size_path)) {
                                        unlink($size_path);
                                    }
                                }
                            }

                            // Elimina la voce nel database
                            wp_delete_attachment($file_id, true);
                        }
                    }
                }
                echo 'Tutti i file sono stati eliminati.';
            } else {
                echo 'Nessun file da eliminare.';
            }
        } else {
            echo 'Nessun file da eliminare.';
        }

        wp_die();
    }
}

new Large_File_Cleaner();